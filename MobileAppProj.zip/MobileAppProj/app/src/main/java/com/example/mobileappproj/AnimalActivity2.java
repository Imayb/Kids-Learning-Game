package com.example.mobileappproj;

import android.content.Intent;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;

public class AnimalActivity2 extends AppCompatActivity {
    TextView etText;
    ImageButton btConvert;

    TextToSpeech textToSpeech;


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_animal2);

        //assign text to speech variable
        etText = findViewById(R.id.txtSlogan);
        btConvert = findViewById(R.id.bt_convert);

        textToSpeech = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int i) {
                if (i == TextToSpeech.SUCCESS) {
                    //select language
                    int lang = textToSpeech.setLanguage(Locale.ENGLISH);
                }
            }
        });

        btConvert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //get textview value
                String s = etText.getText().toString();

                //text convert to speech
                int speech = textToSpeech.speak(s,TextToSpeech.QUEUE_FLUSH, null);
            }
        });

        ImageButton catImageButton = (ImageButton) findViewById(R.id.catButton);
        ImageButton cowImageButton = (ImageButton) findViewById(R.id.cowButton);
        ImageButton horseImageButton = (ImageButton) findViewById(R.id.horseButton);

        ImageButton optionsButton = (ImageButton) findViewById(R.id.Options);

        catImageButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "This is a Cat! Try Again.", Toast.LENGTH_LONG).show();// display the toast on cat button click
            }
        });

        cowImageButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "This is the Cow! Good job!", Toast.LENGTH_LONG).show();// display the toast on cow button click
            }
        });
        horseImageButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "This is a Horse! Try again.", Toast.LENGTH_LONG).show();// display the toast on horse button click
            }
        });


        optionsButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent optionsIntent = new Intent(AnimalActivity2.this, OptionActivity.class);
                startActivity(optionsIntent);
            }
        });
    }
}
