package com.example.mobileappproj;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AnimalActivity2 extends AppCompatActivity {


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_animal2);

        ImageButton catImageButton = (ImageButton) findViewById(R.id.catButton);
        ImageButton cowImageButton = (ImageButton) findViewById(R.id.cowButton);
        ImageButton horseImageButton = (ImageButton) findViewById(R.id.horseButton);

        ImageButton optionsButton = (ImageButton) findViewById(R.id.Options);

        catImageButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "This is a Cat! Try Again.", Toast.LENGTH_LONG).show();// display the toast on cat button click
            }
        });

        cowImageButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "This is the Cow! Good job!", Toast.LENGTH_LONG).show();// display the toast on cow button click
            }
        });
        horseImageButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "This is a Horse! Try again.", Toast.LENGTH_LONG).show();// display the toast on horse button click
            }
        });


        optionsButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent optionsIntent = new Intent(AnimalActivity2.this, OptionActivity.class);
                startActivity(optionsIntent);
            }
        });
    }
}
