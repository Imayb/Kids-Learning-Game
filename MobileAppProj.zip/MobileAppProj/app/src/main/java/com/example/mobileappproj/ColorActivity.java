package com.example.mobileappproj;

import android.content.Intent;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;

public class ColorActivity extends AppCompatActivity {
    TextToSpeech textToSpeech;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_color);

        RadioButton yellowRB = (RadioButton) findViewById(R.id.RB1);
        RadioButton redRB = (RadioButton) findViewById(R.id.RB2);
        RadioButton blueRB = (RadioButton) findViewById(R.id.RB3);

        yellowRB.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Wrong, Try again!", Toast.LENGTH_LONG).show();// display the toast on yello RB click

            }
        });

        redRB.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Wrong, Try again!", Toast.LENGTH_LONG).show();// display the toast on red RB click
            }
        });

        blueRB.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Correct! Good Job!", Toast.LENGTH_LONG).show();// display the toast on Blue RB click
            }
        });


        ImageButton optionsButton = (ImageButton) findViewById(R.id.Options);

    optionsButton.setOnClickListener(new View.OnClickListener() {
        public void onClick(View view) {
            Intent optionsIntent = new Intent(ColorActivity.this, OptionActivity.class);
            startActivity(optionsIntent);
        }
    });

    // Text to speech for the question
        ImageButton convertImageButton = (ImageButton) findViewById(R.id.bt_convert1);

        convertImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //get textview value
                TextView text = (TextView) findViewById(R.id.txtSlogan);
                String words = text.getText().toString();

                StartSpeak(words);
            }

            private void StartSpeak(final String data) {
                textToSpeech = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
                    @Override
                    public void onInit(int i) {
                        if (i == TextToSpeech.SUCCESS) {
                            textToSpeech.setLanguage(Locale.ENGLISH);
                            textToSpeech.setPitch(1.3f);
                            textToSpeech.setSpeechRate(0.7f);
                            textToSpeech.speak(data, TextToSpeech.QUEUE_FLUSH, null);
                        }
                    }
                });
            }
        });

        //Text to speech for yellow
        ImageButton convertImageButton2 = (ImageButton) findViewById(R.id.bt_convert2);

        convertImageButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //get textview value
                TextView text = (TextView) findViewById(R.id.RB1);
                String words = text.getText().toString();

                StartSpeak(words);
            }

            private void StartSpeak(final String data) {
                textToSpeech = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
                    @Override
                    public void onInit(int i) {
                        if (i == TextToSpeech.SUCCESS) {
                            textToSpeech.setLanguage(Locale.ENGLISH);
                            textToSpeech.setPitch(1.3f);
                            textToSpeech.setSpeechRate(0.7f);
                            textToSpeech.speak(data, TextToSpeech.QUEUE_FLUSH, null);
                        }
                    }
                });
            }
        });

        //Text to speech for red
        ImageButton convertImageButton3 = (ImageButton) findViewById(R.id.bt_convert3);

        convertImageButton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //get textview value
                TextView text = (TextView) findViewById(R.id.RB2);
                String words = text.getText().toString();

                StartSpeak(words);
            }

            private void StartSpeak(final String data) {
                textToSpeech = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
                    @Override
                    public void onInit(int i) {
                        if (i == TextToSpeech.SUCCESS) {
                            textToSpeech.setLanguage(Locale.ENGLISH);
                            textToSpeech.setPitch(1.3f);
                            textToSpeech.setSpeechRate(0.7f);
                            textToSpeech.speak(data, TextToSpeech.QUEUE_FLUSH, null);
                        }
                    }
                });
            }
        });

        //Text to speech for blue
        ImageButton convertImageButton4 = (ImageButton) findViewById(R.id.bt_convert4);

        convertImageButton4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //get textview value
                TextView text = (TextView) findViewById(R.id.RB3);
                String words = text.getText().toString();

                StartSpeak(words);
            }

            private void StartSpeak(final String data) {
                textToSpeech = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
                    @Override
                    public void onInit(int i) {
                        if (i == TextToSpeech.SUCCESS) {
                            textToSpeech.setLanguage(Locale.ENGLISH);
                            textToSpeech.setPitch(1.3f);
                            textToSpeech.setSpeechRate(0.7f);
                            textToSpeech.speak(data, TextToSpeech.QUEUE_FLUSH, null);
                        }
                    }
                });
            }
        });

}

}
