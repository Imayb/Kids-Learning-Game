package com.example.mobileappproj;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ColorActivity extends AppCompatActivity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_color);

    }

    public void colorGuess(View v) {
        EditText colorGuessET = findViewById(R.id.colorGuess);
        String colorGuessString = colorGuessET.getText().toString();

        Toast.makeText(this, "The color is " + colorGuessString + ", Good Job!!!", Toast.LENGTH_LONG).show();

    }

}
