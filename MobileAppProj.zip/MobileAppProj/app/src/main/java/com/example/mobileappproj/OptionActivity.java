package com.example.mobileappproj;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.ScrollView;

import androidx.appcompat.app.AppCompatActivity;

public class OptionActivity extends AppCompatActivity {

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        updateView();
    }

    private void updateView() {
        RelativeLayout layout = new RelativeLayout((this));
        ScrollView scrollView = new ScrollView(this);

        //group.setOnCheckedChangeListener();

        // create a back button
        Button backButton = new Button(this);
        backButton.setText("Back to Main Menu");
        backButton.setBackgroundColor(0xFF3700B3);
        backButton.setTextColor(Color.WHITE);


        backButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
               Intent backToMenu = new Intent(OptionActivity.this, MainActivity.class);
               startActivity(backToMenu);
            }
        });



        //scrollView.addView(group);
        layout.addView(scrollView);

        // add back button at bottom
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT);
        params.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
        params.addRule(RelativeLayout.CENTER_HORIZONTAL);
        params.setMargins(0, 0, 0, 1400);
        layout.addView(backButton, params);


        setContentView(layout);
    }
}
