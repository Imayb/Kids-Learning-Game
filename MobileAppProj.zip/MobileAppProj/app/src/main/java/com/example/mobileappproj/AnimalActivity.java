package com.example.mobileappproj;


import android.content.Intent;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.w3c.dom.Text;

import java.util.Locale;


public class AnimalActivity extends AppCompatActivity {

    TextToSpeech textToSpeech;


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_animal);

// set up animal image buttons
        ImageButton pigImageButton = (ImageButton) findViewById(R.id.pigButton);
        ImageButton monkeyImageButton = (ImageButton) findViewById(R.id.monkeyButton);
        ImageButton hippoImageButton = (ImageButton) findViewById(R.id.hippoButton);

        Button nextButton = (Button) findViewById(R.id.nextButton);
        ImageButton optionsButton = (ImageButton) findViewById(R.id.Options);


// perform click event on button's
        pigImageButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "This is a Pig! Good Job!", Toast.LENGTH_LONG).show();// display the toast on pig button click
            }
        });

        monkeyImageButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "This is a Monkey! Try again.", Toast.LENGTH_LONG).show();// display the toast on monkey button click
            }
        });
        hippoImageButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "This is a Hippo! Try again.", Toast.LENGTH_LONG).show();// display the toast on hippo button click
            }
        });

        nextButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent nextButtonIntent = new Intent(AnimalActivity.this, AnimalActivity2.class);
                startActivity(nextButtonIntent);
            }
        });



        optionsButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent optionsIntent = new Intent(AnimalActivity.this, OptionActivity.class);
                startActivity(optionsIntent);
            }
        });

        ImageButton convertImageButton = (ImageButton) findViewById(R.id.bt_convert);

        convertImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //get textview value
                TextView text = (TextView) findViewById(R.id.txtSlogan);
                String words = text.getText().toString();

                StartSpeak(words);
            }

            private void StartSpeak(final String data) {
                textToSpeech = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
                    @Override
                    public void onInit(int i) {
                        if (i == TextToSpeech.SUCCESS) {
                            textToSpeech.setLanguage(Locale.ENGLISH);
                            textToSpeech.setPitch(1.3f);
                            textToSpeech.setSpeechRate(0.7f);
                            textToSpeech.speak(data, TextToSpeech.QUEUE_FLUSH, null);
                        }
                    }
                });
            }
        });
    }
}
