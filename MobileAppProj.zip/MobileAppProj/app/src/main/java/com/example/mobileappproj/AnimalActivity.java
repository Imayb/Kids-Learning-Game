package com.example.mobileappproj;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


public class AnimalActivity extends AppCompatActivity {


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_animal);
// set up animal image buttons
        ImageButton pigImageButton = (ImageButton) findViewById(R.id.pigButton);
        ImageButton monkeyImageButton = (ImageButton) findViewById(R.id.monkeyButton);
        ImageButton hippoImageButton = (ImageButton) findViewById(R.id.hippoButton);

        Button nextButton = (Button) findViewById(R.id.nextButton);
        ImageButton optionsButton = (ImageButton) findViewById(R.id.Options);


// perform click event on button's
        pigImageButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "This is a Pig! Good Job!", Toast.LENGTH_LONG).show();// display the toast on pig button click
            }
        });

        monkeyImageButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "This is a Monkey! Try again.", Toast.LENGTH_LONG).show();// display the toast on monkey button click
            }
        });
        hippoImageButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "This is a Hippo! Try again.", Toast.LENGTH_LONG).show();// display the toast on hippo button click
            }
        });

        nextButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent nextButtonIntent = new Intent(AnimalActivity.this, AnimalActivity2.class);
                startActivity(nextButtonIntent);
            }
        });



        optionsButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent optionsIntent = new Intent(AnimalActivity.this, OptionActivity.class);
                startActivity(optionsIntent);
            }
        });

    }
}
