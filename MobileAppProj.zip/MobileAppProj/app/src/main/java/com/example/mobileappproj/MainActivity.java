package com.example.mobileappproj;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import android.speech.tts.TextToSpeech;
import android.view.View;

import androidx.navigation.ui.AppBarConfiguration;

import com.example.mobileappproj.databinding.ActivityMainBinding;

import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    TextToSpeech textToSpeech;

    private AppBarConfiguration appBarConfiguration;
    private ActivityMainBinding binding;
    private Button btnAnimalGame, btnColorGame, btnShapeGame;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        // setSupportActionBar(binding.toolbar);

        btnAnimalGame = (Button) findViewById(R.id.btnAnimalGame);
        btnColorGame = (Button) findViewById(R.id.btnColorGame);
        btnShapeGame = (Button) findViewById(R.id.btnShapeGame);

        btnAnimalGame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentAnimal = new Intent(MainActivity.this, AnimalActivity.class);
                startActivity(intentAnimal);
            }
        });

        btnColorGame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentColor = new Intent(MainActivity.this, ColorActivity.class);
                startActivity(intentColor);
            }
        });

        btnShapeGame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentColor = new Intent(MainActivity.this, ShapeActivity.class);
                startActivity(intentColor);
            }
        });


        //set up text to speech

        ImageButton convertImageButton = (ImageButton) findViewById(R.id.bt_convert);

        convertImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //get textview value
                TextView text = (TextView) findViewById(R.id.txtSlogan);
                String words = text.getText().toString();

                StartSpeak(words);
            }

            private void StartSpeak(final String data) {
                textToSpeech = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
                    @Override
                    public void onInit(int i) {
                        if (i == TextToSpeech.SUCCESS) {
                            textToSpeech.setLanguage(Locale.ENGLISH);
                            textToSpeech.setPitch(1.3f);
                            textToSpeech.setSpeechRate(0.7f);
                            textToSpeech.speak(data, TextToSpeech.QUEUE_FLUSH, null);
                        }
                    }
                });
            }
        });
    }

        @Override
        public boolean onCreateOptionsMenu (Menu menu){
            // Inflate the menu; this adds items to the action bar if it is present.
            getMenuInflater().inflate(R.menu.menu_main, menu);
            return true;
        }

        @Override
        public boolean onOptionsItemSelected (MenuItem item){
            // Handle action bar item clicks here. The action bar will
            // automatically handle clicks on the Home/Up button, so long
            // as you specify a parent activity in AndroidManifest.xml.
            int id = item.getItemId();

            //noinspection SimplifiableIfStatement
            if (id == R.id.action_option) {
                Intent optionintent = new Intent(this, OptionActivity.class);
                this.startActivity(optionintent);
                return true;
            }

            return super.onOptionsItemSelected(item);
        }
    }