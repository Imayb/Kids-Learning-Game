package com.example.mobileappproj;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;

public class ShapeActivity extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shape);

        ImageButton optionsButton = (ImageButton) findViewById(R.id.Options);

        optionsButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent optionsIntent = new Intent(ShapeActivity.this, OptionActivity.class);
                startActivity(optionsIntent);
            }
        });

    }
    public void shapeGuess(View v) {
        EditText shapeGuessET = findViewById(R.id.shapeGuess);
        String shapeGuessString = shapeGuessET.getText().toString();

        if(shapeGuessString == "circle".toLowerCase(Locale.ROOT)) {
            Toast.makeText(this, "The shape is a circle, Good Job!!!", Toast.LENGTH_LONG).show();
        }
        else {
            Toast.makeText(this, "Incorrect, Try Again!", Toast.LENGTH_LONG).show();
        }

    }

}
